import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        BookRatingAPI ratingAPI = new BookRatingAPI();
        Scanner scanner = new Scanner(System.in);

        String bookName;
        List<Comment> comments;
        do {
            System.out.print("Enter the book name: ");
            bookName = scanner.nextLine();

            System.out.print("Enter the rating (1-5 stars): ");
            int rating = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter your comment: ");
            String comment = scanner.nextLine();

            String userId = "user1";
            String datestamp = "2023-07-06";

            // Create a rating
            ratingAPI.createRating(rating, userId, bookName, datestamp);

            // Create a comment
            ratingAPI.createComment(comment, userId, bookName, datestamp);

            // Retrieve all comments for a book
            comments = ratingAPI.getAllComments(bookName);
            System.out.println("Comments for " + bookName + ":");
            for (Comment c : comments) {
                System.out.println("- " + c.getComment());
            }

            // Retrieve average rating for a book
            double averageRating = ratingAPI.getAverageRating(bookName);
            System.out.println("Average rating for " + bookName + ": " + averageRating);

            System.out.print("Would you like to rate another book? (yes/no): ");
            String answer = scanner.nextLine();
            if (!answer.equalsIgnoreCase("yes")) {

                System.out.println("See you next time!");
                break;
            }
        } while (true);
    }
}



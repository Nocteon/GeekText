import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookRatingSystem {
    private Map<String, Book> books;

    public BookRatingSystem() {
        this.books = new HashMap<>();
    }

    // Create a rating for a book
    public void createRating(int rating, String userId, String bookId, String datestamp) {
        Rating newRating = new Rating(rating, userId, datestamp);
        Book book = books.getOrDefault(bookId, new Book(bookId));
        book.getRatings().add(newRating);
        books.put(bookId, book);
    }

    // Create a comment for a book
    public void createComment(String comment, String userId, String bookId, String datestamp) {
        Comment newComment = new Comment(comment, userId, bookId, datestamp);
        Book book = books.getOrDefault(bookId, new Book(bookId));
        book.getComments().add(newComment);
        books.put(bookId, book);
    }

    // Retrieve a list of all comments for a particular book
    public List<Comment> getAllComments(String bookId) {
        Book book = books.get(bookId);
        if (book != null) {
            return book.getComments();
        }
        return new ArrayList<>();
    }

    // Retrieve the average rating for a book
    public double getAverageRating(String bookId) {
        Book book = books.get(bookId);
        if (book != null) {
            List<Rating> ratings = book.getRatings();
            if (!ratings.isEmpty()) {
                int totalRating = 0;
                for (Rating rating : ratings) {
                    totalRating += rating.getRating();
                }
                return (double) totalRating / ratings.size();
            }
        }
        return 0.0;
    }
}

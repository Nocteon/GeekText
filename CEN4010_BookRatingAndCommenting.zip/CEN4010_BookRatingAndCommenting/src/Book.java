import java.util.ArrayList;
import java.util.List;

public class Book {
    private String bookId;
    private List<Comment> comments;
    private List<Rating> ratings;

    public Book(String bookId) {
        this.bookId = bookId;
        this.comments = new ArrayList<>();
        this.ratings = new ArrayList<>();
    }

    // Getters and Setters

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public List<Rating> getRatings() {
        return ratings;
    }

    public void setRatings(List<Rating> ratings) {
        this.ratings = ratings;
    }
}

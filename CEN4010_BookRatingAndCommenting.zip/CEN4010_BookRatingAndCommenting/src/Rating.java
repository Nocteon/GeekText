public class Rating {

    private int rating;
    private String userId;
    private String bookId;
    private String datestamp;

    public Rating(int rating, String userId, String bookId, String datestamp) {
        this.rating = rating;
        this.userId = userId;
        this.bookId = bookId;
        this.bookId = datestamp;
    }

    // Getters and Setters

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getDatestamp() {
        return datestamp;
    }

    public void setDatestamp(String datestamp) {
        this.datestamp = datestamp;
    }


}

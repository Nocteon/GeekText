public class Comment {

    private String comment;
    private String userId;
    private String bookId;
    private String datestamp;

    public Comment(String comment, String userId, String bookId, String datestamp) {
        this.comment = comment;
        this.userId = userId;
        this.bookId = bookId;
        this.datestamp = datestamp;
    }

    // Getters and Setters
    public String getComment() {
        return comment;
    }

    public String getUserId() {
        return userId;
    }

    public String getBookId() {
        return bookId;
    }

    public String getDatestamp() {
        return datestamp;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setDatestamp(String datestamp) {
        this.datestamp = datestamp;
    }
}









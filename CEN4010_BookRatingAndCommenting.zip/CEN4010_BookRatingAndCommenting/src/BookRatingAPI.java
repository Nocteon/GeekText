import java.util.List;

public class BookRatingAPI {
    private BookRatingSystem ratingSystem;

    public BookRatingAPI() {
        this.ratingSystem = new BookRatingSystem();
    }

    // POST request to create a rating for a book
    public void createRating(int rating, String userId, String bookId, String datestamp) {
        ratingSystem.createRating(rating, userId, bookId, datestamp);
        System.out.println("Rating created successfully.");
    }

    // POST request to create a comment for a book
    public void createComment(String comment, String userId, String bookId, String datestamp) {
        ratingSystem.createComment(comment, userId, bookId, datestamp);
        System.out.println("Comment created successfully.");
    }

    // GET request to retrieve all comments for a book
    public List<Comment> getAllComments(String bookId) {
        return ratingSystem.getAllComments(bookId);
    }

    // GET request to retrieve the average rating for a book
    public double getAverageRating(String bookId) {
        return ratingSystem.getAverageRating(bookId);
    }


}

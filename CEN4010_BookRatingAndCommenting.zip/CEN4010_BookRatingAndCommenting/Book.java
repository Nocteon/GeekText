import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Book {
    private int id;
    private String name;

    public Book(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
    // ...
}

public class Rating {
    private int id;
    private int userId;
    private int bookId;
    private int rating;
    private String datestamp;

    public Rating(int id, int userId, int bookId, int rating, String datestamp) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.rating = rating;
        this.datestamp = datestamp;
    }

    // Getters and setters
    // ...
}

public class Comment {
    private int id;
    private int userId;
    private int bookId;
    private String comment;
    private String datestamp;

    public Comment(int id, int userId, int bookId, String comment, String datestamp) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.comment = comment;
        this.datestamp = datestamp;
    }

    // Getters and setters
    // ...
}
public class Wishlist {
    private int id;
    private int userId;
    private String name;
    private List<Book> books;

    public Wishlist(int id, int userId, String name) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.books = new ArrayList<>();
    }

    // Methods to add, remove, and list books in the wishlist
    public void addBook(Book book) {
        books.add(book);
    }

    public void removeBook(Book book) {
        books.remove(book);
    }

    public List<Book> getBooks() {
        return books;
    }

    // Getters and setters
    // ...
}

public class BookStore {
    private Map<Integer, Book> books;
    private List<Rating> ratings;
    private List<Comment> comments;
    private List<Wishlist> wishlists;

    public BookStore() {
        this.books = new HashMap<>();
        this.ratings = new ArrayList<>();
        this.comments = new ArrayList<>();
        this.wishlists = new ArrayList<>();
    }

    // Book-related methods
    public void addBook(Book book) {
        books.put(book.getId(), book);
    }

    public Book getBookById(int bookId) {
        return books.get(bookId);
    }

    // Rating-related methods
    public void addRating(Rating rating) {
        ratings.add(rating);
    }

    public double getAverageRating(int bookId) {
        int totalRating = 0;
        int count = 0;
        for (Rating rating : ratings) {
            if (rating.getBookId() == bookId) {
                totalRating += rating.getRating();
                count++;
            }
        }
        return count > 0 ? (double) totalRating / count : 0;
    }

    // Comment-related methods
    public void addComment(Comment comment) {
        comments.add(comment);
    }

    public List<Comment> getCommentsByBookId(int bookId) {
        List<Comment> bookComments = new ArrayList<>();
        for (Comment comment : comments) {
            if (comment.getBookId() == bookId) {
                bookComments.add(comment);
            }
        }
        return bookComments;
    }

    // Wishlist-related methods
    public void create
